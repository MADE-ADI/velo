"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Mic, MicOff, Send, Wallet, Volume2, Settings, Menu, Share, Shuffle, Plus } from "lucide-react"

interface Message {
  id: string
  text: string
  isUser: boolean
  timestamp: Date
}

interface Character {
  id: string
  name: string
  avatar: string
  title: string
}

export default function VirtualAIAgent() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "How do you define a dream?",
      isUser: true,
      timestamp: new Date(),
    },
    {
      id: "2",
      text: "I have a dream to free the mind of user interfaces and that mankind will be able to communicate in new and innovative ways.",
      isUser: false,
      timestamp: new Date(),
    },
    {
      id: "3",
      text: "I have a dream that one day the world will no longer rely on fossil fuels.",
      isUser: false,
      timestamp: new Date(),
    },
    {
      id: "4",
      text: "I have a dream that one day every valley shall be exalted.",
      isUser: false,
      timestamp: new Date(),
    },
  ])

  const [inputMessage, setInputMessage] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [volume, setVolume] = useState([75])
  const [selectedCharacter, setSelectedCharacter] = useState("veco")

  const characters: Character[] = [
    { id: "veco", name: "Veco", avatar: "/images/veco-character.png", title: "DATA ANALYSIS" },
    { id: "tesla", name: "Nikola Tesla", avatar: "/placeholder.svg?height=40&width=40", title: "INVENTOR" },
    { id: "curie", name: "Marie Curie", avatar: "/placeholder.svg?height=40&width=40", title: "SCIENTIST" },
  ]

  const handleSendMessage = () => {
    if (inputMessage.trim()) {
      const newMessage: Message = {
        id: Date.now().toString(),
        text: inputMessage,
        isUser: true,
        timestamp: new Date(),
      }
      setMessages([...messages, newMessage])
      setInputMessage("")

      // Simulate AI response
      setTimeout(() => {
        const aiResponse: Message = {
          id: (Date.now() + 1).toString(),
          text: "Thank you for your message. I'm processing your request and will provide a thoughtful response.",
          isUser: false,
          timestamp: new Date(),
        }
        setMessages((prev) => [...prev, aiResponse])
      }, 1000)
    }
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-[#3533CD] relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-black/30" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#3533CD]/20 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl" />

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between p-6">
        <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
          <Menu className="h-6 w-6" />
        </Button>

        <div></div>

        <div className="flex items-center space-x-4">
          <Button variant="ghost" className="text-white hover:bg-white/10">
            <Wallet className="h-5 w-5 mr-2" />
            Connect Wallet
          </Button>
          <Button variant="outline" className="text-white border-white/30 hover:bg-white/10 bg-transparent">
            <Share className="h-4 w-4 mr-2" />
            SHARE
          </Button>
        </div>
      </header>

      <div className="relative z-10 flex h-[calc(100vh-120px)] px-6 pb-6 space-x-6">
        {/* Left Sidebar - Volume Controls */}
        <div className="w-20 flex flex-col items-center space-y-6 bg-black/20 rounded-2xl p-4 backdrop-blur-sm border border-white/10">
          <div className="flex items-center justify-center w-10 h-10 bg-[#3533CD]/20 rounded-full">
            <Volume2 className="h-5 w-5 text-white" />
          </div>

          <div className="flex flex-col items-center space-y-4 h-48">
            <span className="text-white text-xs font-medium">Volume</span>
            <div className="relative h-32 w-2 bg-white/10 rounded-full">
              <div
                className="absolute bottom-0 w-full bg-gradient-to-t from-[#3533CD] to-blue-400 rounded-full transition-all duration-300"
                style={{ height: `${volume[0]}%` }}
              />
              <div
                className="absolute w-4 h-4 bg-white rounded-full border-2 border-[#3533CD] -left-1 transition-all duration-300 cursor-pointer hover:scale-110"
                style={{ bottom: `${volume[0]}%`, transform: "translateY(50%)" }}
              />
            </div>
            <span className="text-white text-xs bg-[#3533CD]/20 px-2 py-1 rounded-full">{volume[0]}%</span>
          </div>

          <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 w-10 h-10 rounded-full">
            <Settings className="h-4 w-4" />
          </Button>
        </div>

        {/* Chat Interface */}
        <div className="flex-1 flex flex-col max-w-md">
          {/* Messages */}
          <div className="flex-1 space-y-4 overflow-y-auto mb-6">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.isUser ? "justify-end" : "justify-start"}`}>
                <div className="flex items-start space-x-3 max-w-xs">
                  {!message.isUser && (
                    <Avatar className="w-8 h-8">
                      <AvatarImage src="/images/veco-character.png" />
                      <AvatarFallback>AI</AvatarFallback>
                    </Avatar>
                  )}
                  <Card
                    className={`p-4 ${
                      message.isUser ? "bg-white text-black" : "bg-black/40 text-white border-white/20"
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                  </Card>
                  {message.isUser && (
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="bg-purple-500 text-white">U</AvatarFallback>
                    </Avatar>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Current Response */}
          <Card className="p-6 mb-6 bg-gradient-to-r from-[#3533CD]/20 to-blue-500/20 border-[#3533CD]/30 backdrop-blur-sm">
            <p className="text-white text-sm leading-relaxed">
              We dance for laughter, we dance for tears, we dance for madness, we dance for fears, we dance for hopes,
              we dance for screams, we are the dancers, we create the dreams.
            </p>
          </Card>

          {/* Input Area */}
          <div className="flex items-center space-x-2">
            <div className="flex-1 relative">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Enter your message..."
                className="bg-black/40 border-[#3533CD]/30 text-white placeholder:text-white/60 pr-12 focus:border-[#3533CD] focus:ring-[#3533CD]"
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              />
              <Button
                onClick={handleSendMessage}
                size="icon"
                className="absolute right-1 top-1 h-8 w-8 bg-[#3533CD] hover:bg-[#3533CD]/80"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* AI Character Display */}
        <div className="flex-1 flex flex-col items-center justify-center relative">
          <div className="relative">
            {/* Character Image */}
            <div className="w-96 h-96 rounded-full bg-gradient-to-br from-[#3533CD]/20 to-blue-400/20 flex items-center justify-center relative overflow-hidden border border-[#3533CD]/30">
              <div className="absolute inset-0 bg-gradient-to-br from-[#3533CD]/30 to-blue-500/30 rounded-full animate-pulse" />
              <img
                src="/images/veco-character.png"
                alt="Veco AI Character"
                className="w-80 h-80 object-cover rounded-full relative z-10"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/10 rounded-full" />
            </div>

            {/* Character Info */}
            <div className="text-center mt-8 relative">
              <h2 className="text-white text-2xl font-bold tracking-wider">
                {characters.find((c) => c.id === selectedCharacter)?.name.toUpperCase()}
              </h2>

              {/* Voice Controls - centered with character name */}
              <div className="absolute left-1/2 transform -translate-x-1/2 -top-2">
                <div className="relative">
                  {/* Radar effect rings */}
                  <div
                    className={`absolute inset-0 rounded-full border-2 border-[#3533CD]/30 ${isRecording ? "animate-ping" : ""}`}
                    style={{ width: "80px", height: "80px", left: "-16px", top: "-16px" }}
                  />
                  <div
                    className={`absolute inset-0 rounded-full border-2 border-[#3533CD]/20 ${isRecording ? "animate-ping" : ""}`}
                    style={{ width: "100px", height: "100px", left: "-26px", top: "-26px", animationDelay: "0.5s" }}
                  />
                  <div
                    className={`absolute inset-0 rounded-full border-2 border-[#3533CD]/10 ${isRecording ? "animate-ping" : ""}`}
                    style={{ width: "120px", height: "120px", left: "-36px", top: "-36px", animationDelay: "1s" }}
                  />

                  {/* Main voice button */}
                  <Button
                    onClick={toggleRecording}
                    variant={isRecording ? "destructive" : "default"}
                    className={`${
                      isRecording ? "bg-red-600 hover:bg-red-700" : "bg-[#3533CD] hover:bg-[#3533CD]/80"
                    } w-12 h-12 rounded-full text-white font-medium transition-all duration-300 hover:scale-110 shadow-lg relative z-10`}
                  >
                    {isRecording ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                  </Button>
                </div>
              </div>

              <p className="text-white/70 text-sm tracking-widest mt-8">
                {characters.find((c) => c.id === selectedCharacter)?.title}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Character Selection */}
      <div className="relative z-10 flex items-center justify-center space-x-4 pb-6">
        {characters.map((character) => (
          <Button
            key={character.id}
            variant="ghost"
            size="icon"
            onClick={() => setSelectedCharacter(character.id)}
            className={`w-12 h-12 rounded-full p-0 ${
              selectedCharacter === character.id ? "ring-2 ring-[#3533CD]" : ""
            }`}
          >
            <Avatar className="w-10 h-10">
              <AvatarImage src={character.avatar || "/placeholder.svg"} />
              <AvatarFallback>{character.name[0]}</AvatarFallback>
            </Avatar>
          </Button>
        ))}

        <Button variant="ghost" size="icon" className="w-12 h-12 rounded-full bg-[#3533CD] hover:bg-[#3533CD]/80">
          <Plus className="h-6 w-6 text-white" />
        </Button>

        <Button variant="outline" className="text-white border-[#3533CD]/30 hover:bg-[#3533CD]/10 ml-4 bg-transparent">
          <Shuffle className="h-4 w-4 mr-2" />
          SHUFFLE
        </Button>
      </div>
    </div>
  )
}
